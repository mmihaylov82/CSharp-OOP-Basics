﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MordorsCrueltyPlan.Models.FoodModels
{
    public class Melon : Food
    {
        public Melon(int points) : base(points)
        {
        }
    }
}