﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MordorsCrueltyPlan.Models.FoodModels
{
    public class Apple : Food
    {
        public Apple(int points) : base(points)
        {
        }
    }
}